PyErrs is a package for more exceptions. 
You can use it for your own programs. 
Now we do not have so many exceptions but we will try to make more in the future.
*Do NOT use "from PyErr import SystemError"!